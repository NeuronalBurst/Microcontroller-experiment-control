clear all
% disp('Press enter if file names have been changed!')
% pause;
vid1 = videoinput('matrox', 1, 'M_PAL');
vid1.SelectedSourceName = 'CH0';
vid2 = videoinput('matrox', 2, 'M_PAL');
vid2.SelectedSourceName=  'CH1';

%% for video 1
config1=triggerinfo(vid1);
triggerconfig(vid1, 'manual')
% triggerconfig(vid1, 'hardware', 'risingEdge', 'TTL');
% triggerconfig(vid1, config1(4));
vid1.FramesPerTrigger = Inf;
% vid1.TriggerRepeat = Inf;
vid1.LoggingMode = 'disk';

% check against overwriting of files
n=1;
while (1)
    fileid=fopen(fullfile('D:\home\nikhil\Videos\', sprintf('sub%d_1.mp4',n)));
    n=n+1;
    if fileid==-1
        
        break
    end
end
diskLogger = VideoWriter(fullfile('D:\home\nikhil\Videos\', sprintf('sub%d_1.mp4',n)), 'MPEG-4');

vid1.DiskLogger = diskLogger;
preview(vid1)

start(vid1);
% wait(vid1,10)
% frameslogged = vid1.FramesAcquired

% x=getdata(vid1);

%% for video 2
config2=triggerinfo(vid2);
 triggerconfig(vid2, 'manual')
% triggerconfig(vid2, 'hardware', 'risingEdge', 'TTL');
% triggerconfig(vid2, config2(4));
% vid2.TriggerRepeat = Inf;
vid2.FramesPerTrigger = Inf;

vid2.LoggingMode = 'disk';

% check against overwriting of files
n=1;
while (1)
    fileid=fopen(fullfile('D:\home\nikhil\Videos\', sprintf('sub%d_2.mp4',n)));
    n=n+1;
    if fileid==-1
        break
    end
end
diskLogger = VideoWriter(fullfile('D:\home\nikhil\Videos\', sprintf('sub%d_2.mp4',n)), 'MPEG-4');

vid2.DiskLogger = diskLogger;
preview(vid2)

start(vid2);
% wait(vid2,10)
% frameslogged = vid2.FramesAcquired

% x=getdata(vid2);

if waitforbuttonpress
    trigger(vid1);
    trigger(vid2);
    disp('VIDEO IS BEING LOGGED')
end

