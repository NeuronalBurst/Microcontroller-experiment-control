#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut led0(p6);
DigitalOut led9(p7);
DigitalOut led1(p8);
DigitalOut led2(p9);
DigitalOut led3(p10);
DigitalOut led4(p11);
DigitalOut led5(p12);
DigitalOut led6(p13);
DigitalOut led7(p14);
DigitalOut led8(p15);
DigitalOut stim1(p16);
DigitalOut stim2(p17);
DigitalOut stim3(p18);
DigitalOut stim4(p19);

InterruptIn bpR(p21);
InterruptIn bpL(p22);
//InterruptIn bpM(p23);
Timer t;

LocalFileSystem local("local"); // Create the local filesystem under the name "local"
FILE *fptr = fopen("/local/dummy.csv", "w"); //dummy file to enable file pointer (fptr) in the void code

float time1, time2, time3;
int var;

void collect_time1()
{
    time2=t.read()-time1;
    printf("The RT is %f seconds\n", time2);
}

void collect_time2()
{
    time3=t.read()-time1;
    printf("The trial duration is %f seconds\n", time3);
}

void collect_time3()   // Interrupt code
{
    if (var>=5 && var<=8) {
        time2=t.read()-time1;
        printf("The RT is %f seconds\n", time2);
        printf("Left button - correct\n");
        fprintf(fptr, "bpL,");
    } else {
        time2=t.read()-time1;
        printf("The RT is %f seconds\n", time2);
        printf("Did not press left button!!\n");
        fprintf(fptr, "bpL!,");
    }
}

//void collect_time4()
//    {
//        if (var>=4 && var<=8)
//        {
//        time2=t.read()-time1;
//        printf("The RT is %f seconds\n", time2);
//        printf("Right button - correct\n");
//        fprintf(fptr, "bpR,");
//        }
//        else
//        {
//        time2=t.read()-time1;
//        printf("The RT is %f seconds\n", time2);
//        printf("Press left button!!\n");
//        fprintf(fptr, "bpR!,");
//        }
//    }

// RUN 3 VM-VS

int main()
{
fclose(fptr); //close the dummy file above
// code to increment file names automatically each time the reset button is pressed
char filename[64];
int n = 0; // set 'n' as integer with the 'int' command 

    // set "filename" equal to the next file to write
    while(1) {
        sprintf(filename, "/local/TIM_R3_%d.csv", n);    // construct the filename
        FILE *fptr = fopen(filename, "r");                // try and open it
        if(fptr == NULL) {                                // if not found, we're done!
            break;
        }
        fclose(fptr);                                     // close the file
        n++;                                            // and try the next one
    }
    
    FILE *fptr = fopen(filename, "w"); //Open the ".csv" on the local file system for writing

    int array_VM[14][4] = {
        {4,2,3,1},
        {3,8,2,1},
        {3,2,5,4},
        {4,2,1,3},
        {3,4,2,5},
        {2,1,3,4},
        {2,8,3,1},
        {1,3,2,4},
        {3,5,2,4},
        {1,3,2,4},
        {2,3,1,4},
        {1,3,6,4},
        {1,3,2,4},
        {5,2,3,4}
    };

    int array_VS[14][4] = {
        {3,4,2,1},
        {6,4,3,1},
        {4,1,2,3},
        {2,3,5,4},
        {4,1,3,2},
        {3,6,4,1},
        {3,2,1,4},
        {2,3,8,1},
        {2,3,8,1},
        {4,3,1,2},
        {4,2,1,3},
        {2,3,4,5},
        {2,4,1,3},
        {8,2,3,1}
    };

    fprintf(fptr,"button_press, onset_time, RT, trial_dur\n"); //Write column names in the text file

    bpR.fall(&collect_time1);
    bpR.rise(&collect_time2);
    bpL.rise(&collect_time3);
//    bpR.rise(&collect_time4);

    int a=1;
    printf("Waiting for trigger\n");

    while(a) { //infinite loop
        led0=1; // fixation LED turns on
        
        if(startIn) { //if TTL input is detected
            printf("Trigger received, 12 seconds before start of run\n");
            t.start(); //start timer
            wait(9.0);// split the 12 second ITI to 9+0.1+2.9
            led9=1; //cue for the next block of motor trials
            wait(0.1);
            led9=0;
            wait(2.9);
                        
            for ( int i=0; i < 14; i++ ) { //number of trials for 5 mins of scanning
                a=1;

                while(a) {
                    if(startIn) { //if TTL input is detected

// Visuo-motor trials


                        for (int j=0; j < 4; j++) {
                            int vis=array_VM[i][j];
                            switch (vis) {
                                case 1:
                                    printf("The onset time for VM-led1 in block %d is %f seconds\n", i+1, t.read());
                                    led1=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led1=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;

                                case 2:
                                    printf("The onset time for VM-led2 in block %d is %f seconds\n", i+1, t.read());
                                    led2=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led2=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;

                                case 3:
                                    printf("The onset time for VM-led3 in block %d is %f seconds\n", i+1, t.read());
                                    led3=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led3=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;

                                case 4 :
                                    printf("The onset time for VM-led4 in block %d is %f seconds\n", i+1, t.read());
                                    led4=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led4=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;


                                case 5:
                                    printf("The onset time for VM-led5 in block %d is %f seconds\n", i+1, t.read());
                                    led5=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led5=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;

                                case 6:
                                    printf("The onset time for VM-led6 in block %d is %f seconds\n", i+1, t.read());
                                    led6=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led6=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;

                                case 7:
                                    printf("The onset time for VM-led7 in block %d is %f seconds\n", i+1, t.read());
                                    led7=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led7=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;

                                case 8 :
                                    printf("The onset time for VM-led8 in block %d is %f seconds\n", i+1, t.read());
                                    led8=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led8=0;
                                    wait(2.0);
                                    fprintf(fptr, "NA,%f,%f,%f\n", time1, time2, time3);
                                    break;
                            }
                        }


// Visual sensory trials
                        printf("ITI of 12 seconds\n");
                        wait(9.0);  // Inter trial interval, split the 12 seconds to 9+3
                        led9=1;
                        wait(0.1);
                        led9=0;
                        wait(0.1);
                        led9=1;
                        wait(0.1);
                        led9=0;
                        wait(2.7);  // cue for sensory trials

                        for (int j=0; j < 4; j++) {
                            int vis2=array_VS[i][j];

                            switch (vis2) {
                                case 1:
                                    var=1; // assignment for the interrupt to work
                                    printf("The onset time for VS-led1 in block %d is %f seconds\n", i+1, t.read());
                                    led1=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led1=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 2:
                                    var=2;
                                    printf("The onset time for VS-led2 in block %d is %f seconds\n", i+1, t.read());
                                    led2=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led2=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 3:
                                    var=3;
                                    printf("The onset time for VS-led3 in block %d is %f seconds\n", i+1, t.read());
                                    led3=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led3=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 4 :
                                    var=4;
                                    printf("The onset time for VS-led4 in block %d is %f seconds\n", i+1, t.read());
                                    led4=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led4=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 5:
                                    var=5;
                                    printf("The onset time for VS-led5 in block %d is %f seconds\n", i+1, t.read());
                                    led5=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led5=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 6:
                                    var=6;
                                    printf("The onset time for VS-led6 in block %d is %f seconds\n", i+1, t.read());
                                    led6=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led6=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 7:
                                    var=7;
                                    printf("The onset time for VS-led7 in block %d is %f seconds\n", i+1, t.read());
                                    led7=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led7=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;

                                case 8:
                                    var=8;
                                    printf("The onset time for VS-led8 in block %d is %f seconds\n", i+1, t.read());
                                    led8=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led8=0;
                                    wait(2.0);
                                    fprintf(fptr, "%f,%f,NA\n", time1, time2);
                                    break;
                            }
                        }
                        printf("ITI of 12 seconds\n");
                        wait(9.0);// split the 12 second ITI to 9+0.1+2.9
                        led9=1; //cue for the next block of motor trials
                        wait(0.1);
                        led9=0;
                        wait(2.9);

                        a=0; //for the TTL input while loop
                    }
                }
            }
            fclose(fptr); //close the file opened for writing experimental parameters
            printf("TRANSFER TIMING FILE!!\n");
            printf("End of Run\n");
            a=0;// for the main trial loop
            led0=0;
        }
    }
}