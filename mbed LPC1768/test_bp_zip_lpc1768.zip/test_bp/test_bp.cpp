#include "mbed.h"
DigitalOut led0(p6);
DigitalOut led9(p7);
DigitalOut led1(p8);
DigitalOut led2(p9);
DigitalOut led3(p10);
DigitalOut led4(p11);
DigitalOut led5(p12);
DigitalOut led6(p13);
DigitalOut led7(p14);
DigitalOut led8(p15);
DigitalOut stim1(p16);
DigitalOut stim2(p17);
DigitalOut stim3(p18);
DigitalOut stim4(p19);
//DigitalOut led2(p8);
DigitalIn bpR(p21);
DigitalIn bpL(p22);
//DigitalIn bpM(p21);
int main() 
{
    while(1)
    {
        //if(bpM) 
//        {
//            led0=1;
//         }   
//            else
//            {
//               led0=0;
//            }
        
        
        if(bpR)
        {
            led1=1;
            wait(0.2);
            led1=0;
         }   
            
                
         if(bpL)
         {
             led2=1;
             wait(0.2);
             led2=0;
         }    
            
         } 
}
      
        