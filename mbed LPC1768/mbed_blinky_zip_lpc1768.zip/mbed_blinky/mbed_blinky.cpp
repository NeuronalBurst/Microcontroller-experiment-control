#include "mbed.h"

DigitalIn myIn(p10);
DigitalOut myled(p12);

int main() 
    { 
    while(1)
//{       if(myIn)
{
        myled = 1;
        wait(0.05);
        myled = 0;
//        wait(0.05);
    }
    //while(1) {
//        if(myIn)
//        myled = 1;
//        wait(0.2);
//        myled = 0;
//        wait(0.2);
      // myled2 = 1;
//        wait(0.2);
//        myled2 = 0;
//        wait(0.2);
//    }
}