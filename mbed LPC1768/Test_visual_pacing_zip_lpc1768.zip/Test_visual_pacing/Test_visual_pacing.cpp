#include "mbed.h"
DigitalOut myled(p6);

void wait(float s);

int main() {

            int a=1;
            myled = 0;
                while (1) {
                    myled = 0;
                    wait(0.25);
                    myled = 1;
                    wait(0.25);
                    //a++;
                }

    myled = 0;        
}