#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut stim0(p6);
DigitalOut stim1(p7);
DigitalOut stim2(p8);
DigitalOut stim3(p9);

int array1[]={1,2,2,0,0,1,3,1,2,0,3,1,2,2,3,3,2,0,0,1,3,1,3,0,3,1,0,1,2,1,1,3,2,2,3,1,3,3,1,2,0,0,2,3,3,0,2,1,0,1
};
 int array2[]={14,18,18,16,18,18,12,12,20,12,12,16,20,18,12,14,16,20,12,20,18,14,12,16,16,12,16,14,14,16,14,14,18,14,20,20,18,14,16,12,20,20,20,14,16,12,16,14,12,12
};

int main() 
{ 
    while(1) 
    {
        while(!startIn) 
        ;

for ( int i=0; i < (sizeof(array1)/sizeof(*array1)); i++ )
        {   
            
            
            int stim_num=0;
            int wait_time=0; 
            stim_num=array1[i];
            wait_time=array2[i];

            
            if (stim_num==0)
                    {
                    stim0=1;
                        
//                    wait(1.0);
                    
                    stim0=0;
                                      
                    wait(wait_time);
                              
                    }
                    
                
                if (stim_num==1)
                    {
                    stim1=1;
                        
//                    wait(1.0);
                    
                    stim1=0;
                                      
                    wait(wait_time);
                              
                    }
                
                if (stim_num==2)
                    {
                    stim2=1;
                        
//                    wait(1.0);
                    
                    stim2=0;
                                      
                    wait(wait_time);
                              
                    }
                
                if (stim_num==3)
                    {
                    stim3=1;
                        
//                    wait(1.0);
                    
                    stim3=0;
                                      
                    wait(wait_time);
                              
                    }
}
}
}