#include "mbed.h"
#include "Speaker.h"

// Speaker test program - euro police style siren now using new Speaker class method
// for documentation see http://mbed.org/users/4180_1/notebook/using-a-speaker-for-audio-output/
// can also be used to play a song, if you have all of the notes and durations
// for musical note frequencies see http://en.wikipedia.org/wiki/Piano_key_frequencies

int main()
{
// setup instance of new Speaker class, mySpeaker using pin 21
// the pin must be a PWM output pin
    Speaker mySpeaker(p14);
    // loops forever playing two notes on speaker
    while(1) {
        mySpeaker.PlayNote(969.0,0.5,0.5);
        mySpeaker.PlayNote(800.0,0.5,0.5);
    }
}

