#include "mbed.h"

Timer t;

int main()
{
    float time1, time2, time3;
    t.start();
    time1=t.read_ms();
    printf("Time taken for 1 line is %f ms\n", time1);
    time2=t.read_ms();
    time3=time2-time1;
    printf("Time taken for printf is %f ms\n", time3);
    }