#include "mbed.h"

DigitalIn startIn(p5);
//DigitalOut led0(p6);
//DigitalOut led9(p7);
//DigitalOut led1(p8);
//DigitalOut led2(p9);
//DigitalOut led3(p10);
DigitalOut stim1(p6);
DigitalOut stim2(p7);
DigitalOut stim3(p8);
DigitalOut stim4(p9);

DigitalOut led0(p11);
DigitalOut led00(p12);
DigitalOut led1(p13);
DigitalOut led2(p14);
DigitalOut led3(p15);
DigitalOut led4(p16);
DigitalOut led5(p17);
DigitalOut led6(p18);
DigitalOut led7(p19);
DigitalOut led8(p20);



int main() {
    while(1) {
        led0 = 1;
        led00 = 1;

        led1 = 1;
         led2 = 1;
         led3 = 1;
         led4 = 1;
         led5 = 1;
         led6 = 1;
         led7 = 1;
         led8 = 1; 

    }
}
