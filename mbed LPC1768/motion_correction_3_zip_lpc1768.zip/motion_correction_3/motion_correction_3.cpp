#include "mbed.h"

DigitalIn startIn(p13);
DigitalOut led0(p6);
DigitalOut led1(p7);
DigitalOut led2(p8);
DigitalOut led3(p9);
DigitalOut led4(p10);
DigitalOut led5(p11);
DigitalOut led6(p12);

 int array[]={1,5,1,1,4,1,5,5,5,1,4,4,6,4,5,3,3,5,1,1,2,3,5,5,1,3,4,3,4,4,2,3,1,6,2,1,3,2,3,3,6,6,1,5,2,3,4,6,3,6
};
 
int main() 
{ 
    while(1) 
    {
       if (startIn)
       {  
       led0=1;
//        wait(0.10);
        
         for ( int i=0; i < (sizeof(array)/sizeof(*array)); i++ )
           {
                  
             wait(17.0);
              
              while(1)
              {
                if (startIn)
                { 
    
                    int led_num=0;
                    led_num=array[i];
            
                        if (led_num==1)
                        {
                        led1=1;
                        wait(1.0);
                        led1=0;
                        break;
                        }
                
                        if (led_num==2)
                        {
                        led2=1;
                        wait(1.0);
                        led2=0;
                        break;
                        }
                
                        if (led_num==3)
                        {
                        led3=1;
                        wait(1.0); 
                        led3=0;
                        break;
                        }
                
                        if (led_num==4)
                        {
                        led4=1;
                        wait(1.0);
                        led4=0;
                        break;
                        }
                    
                        if (led_num==5)
                        {
                        led5=1;
                        wait(1.0);
                        led5=0;
                        break;
                        }
                    
                        if (led_num==6)
                        {
                        led6=1;
                        wait(1.0);
                        led6=0;
                        break;
                        }
                        
                }      
            }
        }
    }
}
}
