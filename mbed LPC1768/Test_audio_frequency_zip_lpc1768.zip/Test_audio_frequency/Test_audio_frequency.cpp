#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut led_w(p6);     //white LED = fixation and pacing
DigitalOut led_r(p8);     //red LED indictaes complex sequence tapping block
DigitalOut led_g(p10);     //green LED indicates simple tapping block
DigitalOut led_le(p16);     
DigitalOut led_ri(p17);     
DigitalOut led_do(p18);
class Speaker          
{
public:
Speaker(PinName pin) : _pin(pin) {
    // _pin(pin) means pass pin to the Speaker Constructor
    }
    // class method to play a note based on PwmOut class
    void PlayNote(float frequency, float duration, float volume) {
        _pin.period(1.0/frequency);
        _pin = volume/2.0;
        wait(duration);
        _pin = 0.0;
    }
 
private:
// sets up specified pin for PWM using PwmOut class 
    PwmOut _pin;
};

Speaker mySpeaker(p21);




int main(){
int a=1;
while(a){
    if (startIn) { 
    
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);
                
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);

                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);

        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);

        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
   
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);

        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
        mySpeaker.PlayNote(100.0, 0.25, 1);
        wait(0.25);
        
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);
                
                mySpeaker.PlayNote(100.0, 0.25, 1);
                wait(0.25);

a=0;
}
}  
}          