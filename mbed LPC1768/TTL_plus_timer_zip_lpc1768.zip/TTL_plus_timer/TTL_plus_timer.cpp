#include "mbed.h"
 
PwmOut TTL(p21);
DigitalIn led_in(p15);
Timer t;
 
int main() {
    t.start();
 
    // specify period first
    TTL.period(2.0f);      // 2 second period
//    led.write(0.50f);      // 50% duty cycle, relative to period
    //led = 0.5f;          // shorthand for led.write()
    TTL.pulsewidth(0.1);   // alternative to led.write, set duty cycle time in seconds
    while(1)
    {
        if (led_in)
        {
            printf("The time taken was %f seconds\n", t.read());
        }
    }
    
    
}
