#include "mbed.h"
DigitalIn startIn(p5);
DigitalOut led_w(p6);     //white LED = fixation and pacing
DigitalOut led_r(p8);     //red LED indictaes complex sequence tapping block
DigitalOut led_g(p10);     //green LED indicates simple tapping block
DigitalOut led_le(p16);     
DigitalOut led_ri(p17);     
DigitalOut led_do(p18);

InterruptIn bp1(p12);
InterruptIn bp2(p13);
InterruptIn bp3(p14);
InterruptIn bp4(p15);

// -------- the following part of the code is needed to produce a sound --------

class Speaker
{
public:
    // class method to play a note based on PwmOut class
    Speaker(PinName pin) : _pin(pin) {
        // _pin(pin) means pass pin to the Speaker Constructor
    }
    void PlayNote(float frequency, float duration, float volume) {
        _pin.period(1.0/frequency);
        _pin = volume/2.0;
        wait(duration);
        _pin = 0.0;
    }

private: // sets up specified pin for PWM using PwmOut class
    PwmOut _pin;
};

Speaker mySpeaker(p21);

// ----------------------------------------------------------------------------

LocalFileSystem local("local"); // Create the local filesystem under the name "local"
FILE *fptr = fopen("/local/dummy.csv", "w"); //dummy file to enable file pointer (fptr) in the void code

Timer t;
float time1, time2, time3;

//int var;

// ----------------------------------------------------------------------------
// the following part of the code, starting with 'void' is executed only
// when the Interrupt pins are active
// That is, only when the buttons are pressed.
// Hence they are checked for input regularly

void collect_time1()
{
    time2=t.read();
    printf("bp1\n");
    fprintf(fptr, "bp1,%f\n", time2);
}

void collect_time2()
{
    time2=t.read();
    printf("bp2\n");
    fprintf(fptr, "bp2,%f\n", time2);
}

void collect_time3()
{
    time2=t.read();
    printf("bp3\n");
    fprintf(fptr, "bp3,%f\n", time2);
}

void collect_time4()
{
    time2=t.read();
    printf("bp4\n");
    fprintf(fptr, "bp4,%f\n", time2);
}

// ----------------------------------------------------------------------------
// -------------------------- Main --------------------------------------------
int main()
{

    fclose(fptr);       //close the dummy file above

    char filename[64];  // code to increment file names automatically each
    // time the reset button is pressed
    int n = 0;


// set "filename" equal to the next file to write
    while(1) {
        sprintf(filename, "/local/R1_TIM_%d.csv", n); // construct the filename
        FILE *fptr = fopen(filename, "r");            // try and open it
        if(fptr == NULL) {                            // if not found, we're done!
            break;
        }
        fclose(fptr);                                 // close the file
        n++;                                          // and try the next one
    }


    FILE *fptr = fopen(filename, "w");  //Open the ".csv" on the local file system for writing
    fprintf(fptr, "onset_stim,button,onset_bp\n"); //column labels of the CSV file




// set arrays for indication of finger for simple finger tapping
    int var_ast[8] = { 2, 1, 4, 3, 4, 2, 1, 3 };

    int var_vst[8] = { 1, 3, 2, 4, 3, 4, 1, 2 };


// assign the 'rise' of the button press signal to the function collect_time
    bp1.rise(&collect_time1);
    bp2.rise(&collect_time2);
    bp3.rise(&collect_time3);
    bp4.rise(&collect_time4);


// -------------------------- Trigger -----------------------------------------
    int a=1;
    printf("Waiting for trigger\n");

while(a){

    if(startIn) { //if TTL input is detected
    t.start(); //start timer
    printf("Trigger received, 15 seconds before start of run\n");

// ------------------------- Initial fixation ---------------------------------
    led_w = 1;
    wait(15.0);
//led_w = 0;


// ------------------------- Running blocks -----------------------------------
    for (int i=0; i<8; i++) {
      a=1;
      while(a) {
          if(startIn) { //if TTL input is detected

// --------------------------- Auditory pacing---------------------------------
// switch through cases and indicate finger by number of blinks


        led_w = 0;                // stop fixation for cue
        int x=var_ast[i];
        printf("Block number %d - AST, cue is %u, start time - %f\n", i+1, x, t.read());


        switch (x) {
            case 1:               // one blink for index finger
                led_g = 1;
                wait(0.85);
                led_g = 0;
                wait(0.15);
                break;

            case 2:               // two blinks for middle finger
                led_g = 1;
                wait(0.35);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.35);
                led_g = 0;
                wait(0.15);
                break;

            case 3:              // three blinks for ring finger
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                break;

            case 4:              // four blinks for little finger
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                break;
        }


// ------------------- auditory pacing with beep sounds ------------------------
        wait(0.35);
        led_w = 1;  // continuous fixation
        int b=0;
        while (b<39) {
            time1=t.read();
            mySpeaker.PlayNote(100.0, 0.25, 1);
            wait(0.25);
            fprintf(fptr,"%f,",time1);
            b++;
        }

        led_w = 1;
        printf("IBI of 15.5 seconds\n");
        wait(15.5); // fixation after block
        led_w = 0;


// --------------------------- Visual pacing ----------------------------------
        int y=var_vst[i];
        printf("Block number %d - VST, cue is %u, time of start - %f\n", i+1, y, t.read());

        switch (y) {
            case 1:              // one blink for index finger
                led_g = 1;
                wait(0.85);
                led_g = 0;
                wait(0.15);
                break;

            case 2:               // two blinks for middle finger
                led_g = 1;
                wait(0.35);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.35);
                led_g = 0;
                wait(0.15);
                break;

            case 3:              // three blinks for ring finger
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                break;

            case 4:               // four blinks for little finger
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                break;
        }

// ------------------------ visual pacing with LEDs ---------------------------
        wait(0.35);
        b=0;
        while (b<39) {
            time1=t.read();
            led_w = 1;
            wait(0.25);
            led_w = 0;
            wait(0.25);
            fprintf(fptr,"%f,",time1);
            b++;
        }


        led_w = 1;
        printf("IBI of 15.5 seconds\n");
        wait(15.5);       // fixation after each block
        a=0;              // for the block while loop

    } // startIn
        
        
    } // while loop
    
 
    } // for loop

    fclose(fptr); //close the file opened for writing experimental parameters
    printf("TRANSFER TIMING FILE!!\n");
    printf("End of Run\n");
    led_w = 0;
    a=0; // for the block while loop
 
 } // startIn
 
 
} // while loop

} // main
