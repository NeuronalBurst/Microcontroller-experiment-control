#include "mbed.h"
#include "beep.h"

AnalogOut speaker(p18);

void wait(float s);


int main() {
        
        speaker = 0;
        wait(1.0);
        
        for (float i=0; i<3; i++) {
        
            int a = 1;
            
            while (a < 41) {
                speaker = 0.0;
                wait(0.4);
                speaker = 1;
                wait(0.1);
                a++;   
            }  
            
            wait(15.0);
        }

}