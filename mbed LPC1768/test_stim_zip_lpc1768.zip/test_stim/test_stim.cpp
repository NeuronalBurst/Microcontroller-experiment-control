#include "mbed.h"

//DigitalIn startIn(p5);
DigitalOut stim1(p6);
DigitalOut stim2(p7);
DigitalOut stim3(p8);
DigitalOut stim4(p9);
//DigitalOut led0(p6);
//DigitalOut led1(p7);
//DigitalOut led2(p8);
//DigitalOut led3(p9);
//DigitalOut led4(p10);
//DigitalOut led5(p11);
//DigitalOut led6(p12);
//DigitalOut led7(p13);
//DigitalOut led8(p14);
//DigitalOut led9(p15);
//DigitalOut stim1(p16);
//DigitalOut stim2(p17);
//DigitalOut stim3(p18);
//DigitalOut stim4(p19);

int main() 
{ 
//    while(1) 
//   {
//        while(!startIn) 
//        ;
        for ( int i=0; i < 50; i++ )
        {
                            stim1=1;
                            wait(0.2);
                            stim1=0;
                            wait(2.0);
                                                       
                            stim2=1;
                            wait(0.2);
                            stim2=0;
                            wait(2.0);

                            stim3=1;
                            wait(0.2);
                            stim3=0;
                            wait(2.0);

                            stim4=1;
                            wait(0.2);
                            stim4=0;
                            wait(2.0);
                            
                            stim1=1;
                            wait(0.05);
                            stim1=0;
                            wait(0.1);
                            stim1=1 ;  
                            wait(0.05);
                            stim1=0;
                            wait(2.0);
                            
                            stim2=1;
                            wait(0.05);
                            stim2=0;
                            wait(0.1);
                            stim2=1 ;  
                            wait(0.05);
                            stim2=0;
                            wait(2.0);
                            
                            stim3=1;
                            wait(0.05);
                            stim3=0;
                            wait(0.1);
                            stim3=1 ;  
                            wait(0.05);
                            stim3=0;
                            wait(2.0);
                            
                            stim4=1;
                            wait(0.05);
                            stim4=0;
                            wait(0.1);
                            stim4=1 ;  
                            wait(0.05);
                            stim4=0;
                            wait(2.0);
                            
                         
                            
           }                 
}

//}


