#include "mbed.h"
 
Serial pc(USBTX, USBRX); // tx, rx
 
int main() 
{ 
    while(1) 
{   
 for ( int i=0; i < 20; i++ )
    
    wait(1.0); 
    pc.printf("1");
//    pc.printf("2");
//    pc.printf("4");
//    pc.printf("8");
        
//     wait(10.0);
//     usb.printf("2");
//     wait(10.0);
//     usb.printf("3");
//     wait(10.0);
//     usb.printf("4");



    
}
}