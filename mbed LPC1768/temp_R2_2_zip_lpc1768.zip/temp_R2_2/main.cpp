#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut led0(p6);
DigitalOut led1(p7);
DigitalOut led2(p8);
DigitalOut led3(p9);
DigitalOut led4(p10);
DigitalOut led5(p11);
DigitalOut led6(p12);
DigitalOut led7(p13);
DigitalOut led8(p14);
DigitalOut stim1(p15);
DigitalOut stim2(p16);
DigitalOut stim3(p17);
DigitalOut stim4(p18);
DigitalIn bpR(p19);
DigitalIn bpL(p20);
DigitalIn bpM(p21);
Timer t;
LocalFileSystem local("local"); // Create the local filesystem under the name "local"

// RUN 2 VS-SS

int main() 
{
    
int array[14][4] = {
{5,6,7,4}
{2,8,1,7}
{1,4,3,6}
{1,4,6,7}
{8,6,7,1}
{8,7,5,2}
{3,2,1,4}
{5,3,2,4}
{2,1,3,8}
{6,7,1,8}
{3,1,6,8}
{3,2,4,1}
{2,3,1,8}
{4,6,5,7}
};  

FILE *fptr = fopen("/local/timing.csv", "w"); //Open "timing.csv" on the local file system for writing
    fprintf(fptr,"button_press,time_for_stim, RT\n"); //Write column names in the text file
    t.start(); //start timer
    int a=1;

    while(a)  //infinite loop
    {

            for ( int i=0; i < 7; i++ ) //number of trials for 5 mins of scanning
            {
               led0=1;
               printf("12 seconds before start of blocks\n");
               wait(12.0);
                float time0, time1, time2;
                int a=1;
                
//                 if(startIn) //if TTL input is detected
                { 

// Visual sensory trials


                for (int j=0; j < 4; j++)
                {                 
                  int vis=array[2*i][j];
                   
                        switch (vis) 
                        {
                            case 1:
                            led1=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led1 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led1=0;
                                                        
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                             
                            case 2:
                            led2=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led2 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led2=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 3:
                            led3=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led3 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led3=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 4 :
                            led4=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led4 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led4=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 5:
                            led5=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led5 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led5=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                             
                            case 6:
                            led6=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led6 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led6=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 7:
                            led7=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led7 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led7=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 8 :
                            led8=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for VS-led8 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led8=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                                    } 
                  }
                  printf("ITI of 12 seconds\n");
                  wait(12.0); // Inter trial interval


// Somatosensory sensory trials

                  
                  for (int j=0; j < 4; j++)
                  {
                    int stim=array[2*i+1][j];
           
                        switch (stim) 
                        {
                            case 1:
                            stim1=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim1 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            stim1=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                             
                            case 2:
                            stim2=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim2 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            stim2=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 3 :
                            stim3=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim3 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            stim3=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 4 :
                            stim4=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim4 in block %d is %f seconds\n", i+1, time0); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            stim4=0;
                            a=1;                            
                            while(a)
                            {
                                if (bpL)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 5:
                            stim1=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim5 in block %d is %f seconds\n", i+1, time0);
                            wait(0.4);
                            stim1=0;
                            a=1;
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                             
                            case 6:
                            stim2=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim6 in block %d is %f seconds\n", i+1, time0);
                            wait(0.4);
                            stim2=0;
                            a=1;
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 7 :
                            stim3=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim7 in block %d is %f seconds\n", i+1, time0);
                            wait(0.4);
                            stim3=0;
                            a=1;
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                            
                            case 8 :
                            stim4=1 ;
                            time0=t.read();
                            time1=t.read_ms();
                            printf("The time taken for SS-stim8 in trial %d is %f seconds\n", i+1, time0);
                            wait(0.4);
                            stim4=0;
                            a=1;
                            while(a)
                            {
                                if (bpR)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                    wait(1.0);
                                }
                            }
                            break;
                                     }
                                      
                 }                                  
               printf("ITI of 12 seconds\n");
               wait(12.0); // Inter trial interval
                
            }
        }
}
}
