#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut led0(p6);
DigitalOut led1(p7);
DigitalOut led2(p8);
DigitalOut led3(p9);
DigitalOut led4(p10);
DigitalOut led5(p11);
DigitalOut led6(p12);
DigitalOut led7(p13);
DigitalOut led8(p14);
DigitalOut stim1(p15);
DigitalOut stim2(p16);
DigitalOut stim3(p17);
DigitalOut stim4(p18);
DigitalIn bpR(p19);
DigitalIn bpL(p20);
DigitalIn bpM(p21);
Timer t;
LocalFileSystem fs("fs");



// RUN 1 VM-SM

int main() 
{
    
int array[14][4] = {
{4,2,5,7},
{3,4,1,2},
{1,8,5,4},
{3,4,2,1},
{5,3,8,1},
{2,3,1,4},
{7,4,6,2},
{4,2,1,3},
{5,7,2,3},
{1,4,2,3},
{8,4,6,1},
{3,2,4,1},
{7,2,3,5},
{4,3,1,2}
};          //8 target arrays and 4 target arrays alternate since there are 8 visual targets and 4 stim targets

   
    t.start(); //start timer
    while(1)  //infinite loop
    {

        led0=1;
        int vis=array[0][0];
        printf("%d\n", vis);

//        wait(20.0);
    
            for ( int i=0; i < 14; i++ ) //number of trials for 5 mins of scanning
            {
            float time1, time2, time3;
            int a=1;
//                  if(startIn) //if TTL input is detected
//                { 

// Visual motor trials
                
                for (int j=0; j < 4; j++)
                {           
                   vis=array[2*i][j];
                   printf("%d\n", vis);
                        if (vis == 4)
                        {
                            led1=1 ;
                            time1=t.read_ms();
                            printf("The time taken for led1 in trial number %d is %f seconds\n", i, t.read()); //DISPLAY JUST THE TIME AND NOT THE PHRASE?
                            wait(0.2); 
                            led1=0;
                                                       
                            while(a)
                            {
                                if (!bpM)
                                {
                                    time2=t.read_ms();
                                    printf("The RT is %f milliseconds\n", time2-time1);
                                    a=0;
                                }
                                 
                            }
                                 a=1;
                                 while(a)
                                 {
                                     if (bpM)
                                        {
                                        time3=t.read_ms();
                                        printf("The trial duration is %f milliseconds\n", time3-time2);
                                        a=0;
                                        }
                                 }
                                 
}
}
}
}
}                                 
 //                           break;