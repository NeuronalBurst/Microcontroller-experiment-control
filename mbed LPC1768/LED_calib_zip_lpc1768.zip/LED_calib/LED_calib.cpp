#include "mbed.h"

DigitalOut led_w(p6);     
DigitalOut led_up(p8);     
DigitalOut led_g(p10);    

DigitalOut led_le(p16);     
DigitalOut led_ri(p17);     
DigitalOut led_do(p18);




 int main (){
while (1){

    led_le = 1;
    led_ri = 1;
    led_up = 1;
    led_do = 1;
    
    
}    

}
