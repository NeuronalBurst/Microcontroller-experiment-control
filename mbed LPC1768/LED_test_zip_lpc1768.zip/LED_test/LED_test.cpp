#include "mbed.h"

DigitalOut led_w(p6);     //white LED = fixation and pacing
DigitalOut led_r(p8);     //red LED indictaes complex sequence tapping block
DigitalOut led_g(p10);     //green LED indicates simple tapping block

DigitalOut led_le(p16);     
DigitalOut led_ri(p17);     
DigitalOut led_do(p18);




 int main (){
while (1){

    led_w = 1;
    led_r = 1;
    led_g = 1;
    led_le =1;
    led_ri = 1;
    led_do = 1;
    
}    

}
