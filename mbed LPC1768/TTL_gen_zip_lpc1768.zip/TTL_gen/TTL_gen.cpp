#include "mbed.h"
 
PwmOut TTL(p21);
 
int main() {
   
 
    // specify period first
    TTL.period(2.0f);      // 2 second period
//    led.write(0.50f);      // 50% duty cycle, relative to period
    //led = 0.5f;          // shorthand for led.write()
    TTL.pulsewidth(0.1);   // alternative to led.write, set duty cycle time in seconds
    while(1);
       
}
