#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut led0(p6);
DigitalOut led9(p7);
DigitalOut led1(p8);
DigitalOut led2(p9);
DigitalOut led3(p10);
DigitalOut led4(p11);
DigitalOut led5(p12);
DigitalOut led6(p13);
DigitalOut led7(p14);
DigitalOut led8(p15);
DigitalOut stim1(p16);
DigitalOut stim2(p17);
DigitalOut stim3(p18);
DigitalOut stim4(p19);

//InterruptIn bpR(p21);
//InterruptIn bpL(p22);
//InterruptIn bpM(p23);
Timer t;

LocalFileSystem local("local"); // Create the local filesystem under the name "local"

float time1, time2, time3;

FILE *fptr = fopen("/local/all_vis.csv", "w"); //Open "timing.csv" on the local file system for writing



// All visual test

int main()
{

 

    fprintf(fptr,"onset_time\n"); //Write column names in the text file


    int a=1;

    while(a) //infinite loop
    { 

        if(startIn) //if TTL input is detected
        { 

            t.start(); //start timer
                  
          
          led0=1;  
         for (int i=0; i<22; i++)
         {

                a=1;

                while(a) 
                {
                    if(startIn) //if TTL input is detected
                    { 
 
 //Fixation trials                   
                    printf("The onset time of 12s fixation block %d is %f seconds\n", i+1, t.read());
                    time1=t.read();
                    wait(12.0);
                    fprintf(fptr, "%f\n", time1);

// Target trials
        printf("The onset time of 15s target block %d is %f seconds\n", i+1, time1=t.read());
         for (int j=0; j<30; j++) // 2hz stimulation for 15s
         {
        
         led1 = 1;   
         led2 = 1;
         led3 = 1;
         led4 = 1;
         led5 = 1;
         led6 = 1;
         led7 = 1;
         led8 = 1; 
        wait(0.2);
        
         led1 = 0;   
         led2 = 0;
         led3 = 0;
         led4 = 0;
         led5 = 0;
         led6 = 0;
         led7 = 0;
         led8 = 0; 
         
         wait(0.3);
         }
         fprintf(fptr, "%f\n", time1);
          a=0; //for the second trial loop
         }
         
         }
         

         }
       
         fclose(fptr); //close the file opened for writing experimental parameters
            printf("TRANSFER TIMING FILE!!\n");
            printf("End of Run\n");
            a=0;// for the main trial loop
            led0=0;
        }
}
}