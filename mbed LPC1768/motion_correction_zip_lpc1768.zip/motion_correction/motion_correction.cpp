#include "mbed.h"

DigitalIn startIn(p5);
DigitalIn stopIn(p6);
DigitalOut led0(p7);
DigitalOut led1(p8);
DigitalOut led2(p9);
DigitalOut led3(p10);
DigitalOut led4(p11);
DigitalOut led5(p12);
DigitalOut led6(p13);

 int array1[]={1,5,1,1,4,1,5,5,5,1,4,4,6,4,5,3,3,5,1,1,2,3,5,5,1,3,4,3,4,4,2,3,1,6,2,1,3,2,3,3,6,6,1,5,2,3,4,6,3,6
};
 int array2[]={14,18,18,16,18,18,12,12,20,12,12,16,20,18,12,14,16,20,12,20,18,14,12,16,16,12,16,14,14,16,14,14,18,14,20,20,18,14,16,12,20,20,20,14,16,12,16,14,12,12
};


int main() 
{ 
    while(1) 
    {
        while(!startIn) 
        ;
    
    led0=1;
    wait(20.0);
    
        for ( int i=0; i < (sizeof(array1)/sizeof(*array1)); i++ )
        {   
            
            
            int led_num=0;
            int wait_time=0; 
            led_num=array1[i];
            
                if (led_num==1)
                    {
                    led1=1;
                        
                    wait(1.0);
                    
                    led1=0;
                    
                    if( stopIn )
                            {led0=0;
                            break;}
                    
                    wait_time=array2[i];
                    wait(wait_time);
                        if( stopIn )
                           {led0=0;  
                            break;}                    
                    }
                    
                
                if (led_num==2)
                    {
                    led2=1;
                    
                    wait(1.0);
                    
                    led2=0;
                    
                    if( stopIn )
                            {led0=0;
                            break;}
                    
                    wait_time=array2[i];
                    wait(wait_time);
                        if( stopIn )
                           {led0=0;  
                            break;} 
                    }
                
                if (led_num==3)
                    {
                    led3=1;
 
                    wait(1.0); 
                    
                     led3=0;
                    
                    if( stopIn )
                            {led0=0;
                            break;}
                    
                    wait_time=array2[i];        
                    wait(wait_time);
                        if( stopIn )
                            {led0=0;  
                            break;}
                    }
                
                if (led_num==4)
                    {
                    led4=1;

                    wait(1.0);
                    
                    led4=0;
                    
                    if( stopIn )
                            {led0=0;
                            break;}
                    
                    wait_time=array2[i];        
                    wait(wait_time);
                        if( stopIn )
                            {led0=0;  
                            break;}
                    }
                    
                if (led_num==5)
                    {
                    led5=1;
 
                    wait(1.0);
                    
                    led5=0;
                    
                    if( stopIn )
                            {led0=0;
                            break;}
                    
                    wait_time=array2[i];  
                    wait(wait_time);
                        if( stopIn )
                            {led0=0;  
                            break;}
                    }
                    
                if (led_num==6)
                    {
                    led6=1;
  
                    wait(1.0);
                    
                    led6=0;
                    
                    if( stopIn )
                            {led0=0;
                            break;}
                    
                    wait_time=array2[i];
                    wait(wait_time);
                        if( stopIn )
                            {led0=0;  
                            break;}
                    }
            
            
        }
    }
}
