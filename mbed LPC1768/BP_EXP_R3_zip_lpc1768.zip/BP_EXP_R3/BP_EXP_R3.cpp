#include "mbed.h"

DigitalIn startIn(p5);
DigitalOut led0(p6);
DigitalOut led9(p7);
DigitalOut led1(p8);
DigitalOut led2(p9);
DigitalOut led3(p10);
DigitalOut led4(p11);
DigitalOut led5(p12);
DigitalOut led6(p13);
DigitalOut led7(p14);
DigitalOut led8(p15);
DigitalOut stim1(p16);
DigitalOut stim2(p17);
DigitalOut stim3(p18);
DigitalOut stim4(p19);

InterruptIn bpR(p21);
Timer t;

LocalFileSystem local("local"); // Create the local filesystem under the name "local"
FILE *fptr = fopen("/local/dummy.csv", "w"); //dummy file to enable file pointer (fptr) in the void code

float time1, time2, time3;
int var;

void collect_time1()
{
    if (var>=5 && var<=8) {
        time2=t.read()-time1;
        printf("Button pressed, the RT is %f seconds\n", time2);
        fprintf(fptr, "bp,");
        }
}

//void collect_time2()
//{
//    time3=t.read()-time1;
//    printf("The trial duration is %f seconds\n", time3);
//}

// RUN 1 VBT-VCT

int main()
{

// code to increment file names automatically each time the reset button is pressed
    char filename[64];
    int n = 0; // set 'n' as integer with the 'int' command

    // set "filename" equal to the next file to write
    while(1) {
        sprintf(filename, "/local/TIM_R1_%d.csv", n);    // construct the filename
        FILE *fptr = fopen(filename, "r");                // try and open it
        if(fptr == NULL) {                                // if not found, we're done!
            break;
        }
        fclose(fptr);                                     // close the file
        n++;                                            // and try the next one
    }

    FILE *fptr = fopen(filename, "w"); //Open the ".csv" on the local file system for writing

    int array_VBP[14][4] = {
        {3,1,8,2},
        {1,2,4,3},
        {4,5,2,3},
        {2,3,4,1},
        {4,1,3,2},
        {2,4,1,7},
        {1,4,2,3},
        {2,4,5,3},
        {1,8,3,2},
        {4,1,3,2},
        {2,8,1,3},
        {4,2,1,3},
        {1,3,8,2},
        {3,1,2,4}
    };

    int array_SBP[14][4] = {
        {4,3,2,1},
        {1,8,2,3},
        {7,4,2,1},
        {2,3,4,1},
        {4,2,1,3},
        {1,3,6,4},
        {3,2,4,5},
        {3,4,1,2},
        {5,4,2,3},
        {4,2,3,1},
        {1,3,4,2},
        {2,7,4,1},
        {4,3,2,1},
        {3,2,5,4}
    };

    fprintf(fptr,"bp, stim_onset_time, RT, onset+RT\n"); //Write column names in the text file

    bpR.rise(&collect_time1); // Assign function collect time written above to the 'rise' of the button press
//    bpR.fall(&collect_time2);


    int a=1;
    printf("Waiting for trigger\n");

    while(a) { //infinite loop
        led0=1; // fixation LED turns on

        if(startIn) { //if TTL input is detected
            printf("Trigger received, 12 seconds before start of run\n");
            wait(12.0);

            for ( int i=0; i < 14; i++ ) { //number of blocks for 10 mins of scanning
                a=1;
                while(a) {

                    if(startIn) { //if TTL input is detected
                        t.start(); //start timer


// Visual - press trials

                        for (int j=0; j < 4; j++) {

                            int vis=array_VBP[i][j];
                            switch (vis) {
                                case 1:
                                    var=1;
                                    led1=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led1=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, " ,%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led1 in block %d is %f seconds\n", i+1, time1);                                    
                                    break;

                                case 2:
                                    var=2;
                                    led2=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led2=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, " ,%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led2 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 3:
                                    var=3;
                                    led3=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led3=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, " ,%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led3 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 4 :
                                    var=4;
                                    led4=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led4=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, " ,%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led2 in block %d is %f seconds\n", i+1, time1);
                                    break;


                                case 5:
                                    var=5;
                                    led5=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led5=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, "%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led5 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 6:
                                    var=6;
                                    led6=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led6=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, "%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led6 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 7:
                                    var=7;
                                    led7=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led7=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, "%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led7 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 8 :
                                    var=8;
                                    led8=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led8=0;
                                    wait(2.0);
                                    time3=time1+time2;
                                    fprintf(fptr, "%f,%f,%f\n", time1, time2, time3);
                                    printf("The onset time for VBT-led8 in block %d is %f seconds\n", i+1, time1);
                                    break;
                            }
                        }


                        printf("ITI of 20 seconds\n");
                        wait(20.0);  // Inter trial interval


// Visual counting trials


                        for (int j=0; j < 4; j++) {
                            int vis=array_SBP[i][j];

                            switch (vis) {
                                case 1:
                                    led1=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led1=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led1 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 2:
                                    led2=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led2=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led2 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 3:
                                    led3=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led3=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led3 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 4 :
                                    led4=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led4=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led4 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 5:
                                    led5=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led5=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led5 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 6:
                                    led6=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led6=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led6 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 7:
                                    led7=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led7=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led7 in block %d is %f seconds\n", i+1, time1);
                                    break;

                                case 8:
                                    led8=1 ;
                                    time1=t.read();
                                    wait(0.2);
                                    led8=0;
                                    wait(2.0);
                                    fprintf(fptr, " ,%f\n", time1);
                                    printf("The onset time for VCT-led8 in block %d is %f seconds\n", i+1, time1);
                                    break;
                            }

                        }
                        printf("ITI of 20 seconds\n");
                        wait(20.0);  // Inter trial interval
                        a=0; //for the TTL input while loop
                    }
                }

            }
            fclose(fptr); //close the file opened for writing experimental parameters
            printf("TRANSFER TIMING FILE!!\n");
            printf("End of Run\n");
            a=0;// for the main trial loop
            led0=0;

        }
    }
}