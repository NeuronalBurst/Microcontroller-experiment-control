#include "mbed.h"

DigitalOut led_w(p6);     
DigitalOut led_up(p8);     
DigitalOut led_g(p10);    

DigitalOut led_le(p16);     
DigitalOut led_ri(p17);     
DigitalOut led_do(p18);
