#include "mbed.h"

//DigitalIn startIn(p5);
DigitalOut stim1(p6);
DigitalOut stim2(p7);
DigitalOut stim3(p8);
DigitalOut stim4(p9);
//DigitalOut led0(p6);
//DigitalOut led1(p7);
//DigitalOut led2(p8);
//DigitalOut led3(p9);
DigitalOut led4(p10);
DigitalOut led5(p11);
DigitalOut led6(p12);
DigitalOut led7(p13);
DigitalOut led8(p14);
DigitalOut led9(p15);
//DigitalOut stim1(p16);
//DigitalOut stim2(p17);
//DigitalOut stim3(p18);
//DigitalOut stim4(p19);

int main()
{
//    while(1)
//   {
//        while(!startIn)
//        ;
    int array[1][20] = {1,4,2,3,1,4,2,3,2,3,4,1,2,1,3,4,4,3,1,2};
    int array2[1][20] = {1,1,2,1,1,4,2,3,2,3,4,1,2,1,3,4,4,3,1,2}; 
   for ( int i=0; i < 40; i++ ) {
        
        
        int stim=array[0][j];
        printf("stim no. is %i\n",stim);
        switch (stim) {

            case 1:

                stim2=1;
                wait(0.05);
                stim2=0;
                wait(0.1);
                stim2=1 ;
                wait(0.05);
                stim2=0;
                wait(0.25);
                break;

            case 2:
                stim1=1;
                wait(0.1);
                stim1=0;
                wait(0.1);
                stim1=1 ;
                wait(0.1);
                stim1=0;
                wait(0.25);


            case 3:
                stim1=1;
                wait(0.15);
                stim1=0;
                wait(0.2);
                stim1=1 ;
                wait(0.15);
                stim1=0;
                wait(0.25);

                break;

            case 4:
                stim1=1;
                wait(0.25);
                stim1=0;
                wait(0.25);
                stim1=1 ;
                wait(0.25);
                stim1=0;
                wait(0.25);
                break;




        }
    }

}


