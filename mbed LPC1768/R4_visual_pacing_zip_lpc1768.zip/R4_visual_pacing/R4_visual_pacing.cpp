#include "mbed.h"
DigitalIn startIn(p5);
DigitalOut led_w(p6);     //white LED = fixation and pacing
DigitalOut led_r(p8);     //red LED indictaes complex sequence tapping block
DigitalOut led_g(p10);     //green LED indicates simple tapping block
DigitalOut led_le(p16);     
DigitalOut led_ri(p17);     
DigitalOut led_do(p18);

InterruptIn bp1(p12);
InterruptIn bp2(p13);
InterruptIn bp3(p14);
InterruptIn bp4(p15);

// ----------------------------------------------------------------------------

LocalFileSystem local("local"); // Create the local filesystem under the name "local"
FILE *fptr = fopen("/local/dummy.csv", "w"); //dummy file to enable file pointer (fptr) in the void code

Timer t;
float time1, time2, time3;
//int var;


// ----------------------------------------------------------------------------
// the following part of the code, starting with 'void' is executed only
// when the Interrupt pins are active
// That is, only when the buttons are pressed.
// Hence they are checked for input regularly

void collect_time1()
{
    time2=t.read();
    printf("bp1\n");
    fprintf(fptr, "bp1,%f\n", time2);
}

void collect_time2()
{
    time2=t.read();
    printf("bp2\n");
    fprintf(fptr, "bp2,%f\n", time2);
}

void collect_time3()
{
    time2=t.read();
    printf("bp3\n");
    fprintf(fptr, "bp3,%f\n", time2);
}

void collect_time4()
{
    time2=t.read();
    printf("bp4\n");
    fprintf(fptr, "bp4,%f\n", time2);
}





// ----------------------------------------------------------------------------
// ---------------------------- Main -------------------------------------------

int main()
{

    fclose(fptr); //close the dummy file above

// code to increment file names automatically each time the reset button is pressed
    char filename[64];
    int n = 0; // set 'n' as integer with the 'int' command

    // set "filename" equal to the next file to write
    while(1) {
        sprintf(filename, "/local/R4_TIM_%d.csv", n);    // construct the filename
        FILE *fptr = fopen(filename, "r");                // try and open it
        if(fptr == NULL) {                                // if not found, we're done!
            break;
        }
        fclose(fptr);                                     // close the file
        n++;                                            // and try the next one
    }

    FILE *fptr = fopen(filename, "w"); //Open the ".csv" on the local file system for writing
    fprintf(fptr, "onset_stim,button,onset_bp\n"); //column labels of the CSV file


    int var_vst[8] = {3, 2, 4, 1, 4, 1, 3, 2};

    bp1.rise(&collect_time1); // assign the 'rise' of the button press signal to the function collect_time1
    bp2.rise(&collect_time2);
    bp3.rise(&collect_time3);
    bp4.rise(&collect_time4);

    int a=1;
    printf("Waiting for trigger\n");
    while(a){

    if(startIn) { //if TTL input is detected
    t.start(); //start timer
    printf("Trigger received, 15 seconds before start of run\n");



    led_w = 1;     // continuous initial fixation for 15 s
    wait(15);
    led_w = 0;

    for (int i=0; i<8; i++) {

        a=1;
        while(a) {
            if(startIn) { //if TTL input is detected


// ------------------------- simple tapping block -----------------------------
        int x=var_vst[i];
            printf("Block number %d - VST, cue is %u, start time - %f\n", i+1, x, t.read());


        switch (x)   {
            case 1:         
                led_g = 1;
                wait(0.85);
                led_g = 0;
                wait(0.15);
            
            break;

            case 2:         
                led_g = 1;
                wait(0.35);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.35);
                led_g = 0;
                wait(0.15);
            
            break;

            case 3:              // three blinks for ring finger
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1833);
                led_g = 0;
                wait(0.15);
                break;

            case 4:         
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
                led_g = 1;
                wait(0.1);
                led_g = 0;
                wait(0.15);
            
            break;
        }


// ------------------------ pacing for simple task ---------------------------
        wait(0.35);
        int b=0;
        while (b<39) {
            time1=t.read();
            led_w = 1;
            wait(0.25);
            led_w = 0;
            wait(0.25);
            fprintf(fptr,"%f,",time1);
            b++;
        }

        led_w = 1;
        printf("IBI of 15.5 seconds\n");
        wait(15.5);        // fixation at the end of the block
        led_w = 0;




// ------------------------ complex tapping block -----------------------------

        //indication of block and task
        printf("Block number %d, VCT, start time - %f\n", i+1, t.read());
        led_r = 1;
        wait(0.85);
        led_r = 0;
        wait(0.15);


// ------------------------ pacing for complex task ---------------------------
        wait(0.35);
        b=0;
        while (b<39) {
            time1=t.read();
            led_w = 1;
            wait(0.25);
            led_w = 0;
            wait(0.25);
            fprintf(fptr,"%f,",time1);
            b++;
        }


        led_w = 1;
        printf("IBI of 15.5 seconds\n");
        wait(15.5);       // fixation after each block
        a=0;              // for the block while loop

    } // startIn
        
        
    } // while loop
    
 
    } // for loop

    fclose(fptr); //close the file opened for writing experimental parameters
    printf("TRANSFER TIMING FILE!!\n");
    printf("End of Run\n");
    led_w = 0;
    a=0; // for the block while loop
 
 } //  startIn
 
 
} // while loop

} // main
