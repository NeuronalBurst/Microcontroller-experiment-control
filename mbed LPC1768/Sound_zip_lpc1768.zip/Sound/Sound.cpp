#include "mbed.h"

DigitalIn myIn(p10);
DigitalOut mySound(p12);

int main() 
    { 
    while(1)
{       if(myIn)
        mySound = 1;
        wait(0.05);
        mySound = 0;
        
        
        }
}